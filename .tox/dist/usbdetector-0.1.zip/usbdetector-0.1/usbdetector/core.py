__author__ = 'stas.savinov'

# https://github.com/walac/pyusb/blob/master/docs/tutorial.rst

class MainLogic(object):

    def __init__(self):
        pass

